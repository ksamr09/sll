pkg install python

pkg install python3

pkg install python-pip

pkg install python3-pip

pip3 install rsa

pip3 install requests

pip3 install googletrans

pip3 install bs4

pip3 install requests

pip3 install rsa

pip3 install thrift

pip3 install bs4

pip3 install pytz

pip3 install humanfriendly

pip3 install gtts

pip3 install googletrans

pip3 install wikipedia

pip3 install youtube_dl

pip3 install ffmpy

pip3 install pafy

pip3 install tweepy

pip3 install goslate

pip3 install html5lib
